# Fog Is Coming: Deadly Fog

**For one day the world is quiet while a clock ticks down. Then the fog comes.**
Every day it gets thicker and darker, and on the eighth day it starts to kill.
The only things that keep you alive are **light** and a **sealed shelter**. The sun won't save you.

A survival horror mod about preparing for something you can't fight.

---

## How it plays

| Stage | Starts | What happens |
|---|---|---|
| **The Calm** | day 0 | A normal world. The HUD shows `FOG IS COMING` and a countdown, with a mechanical clock ticking under it. The ticking gets louder near the end. |
| **I: The Arrival** | day 1 | A light, cold fog creeps in. Wind starts to moan. |
| **II: The Thickening** | day 6 | Dense grey fog. Distant sounds get muffled and something rumbles far away. |
| **III: The Deadly Fog** | day 8 | Dark, rolling fog that comes in and pulls back in waves. Anyone left unprotected takes damage, and it gets worse until they die. **It never leaves.** |

### Staying alive
- **Light.** Stand near a lit torch, lantern, campfire, glowstone, sea lantern, redstone lamp and so on. Fake light doesn't count: an extinguished campfire, an unpowered lamp or a torch behind a wall won't help.
- **Shelter.** A real, closed house protects you. A one-block pit with a lid doesn't. Break one wall block and the fog gets in right away.
- When you leave safety you get a few seconds of grace and a heartbeat, then the fog starts to hurt. Armor doesn't help.

## Atmosphere
- A smooth fog built on Minecraft's own fog. The hand and the HUD stay clear, and the server view distance is never changed.
- **Built-in shaders, no OptiFine or Oculus needed:**
  - volumetric fog with slowly drifting 3D clumps, thicker near the ground;
  - soft halos around torches, lanterns and fires;
  - a cold, film-like look in thick fog.
- Original sounds: a ticking clock, wind gusts, distant rumbles, things moving in the fog, a heartbeat, and a low drone while you're exposed.
- A clean HUD with stage titles and `YOU ARE EXPOSED` / `YOU ARE SAFE` that fade in and out without flashing.

## Multiplayer and servers
- Works in singleplayer and on dedicated servers. **Install it on both the server and every client.**
- All gameplay runs on the server: stages, protection checks and damage. Progress is saved in the world and survives restarts.
- By default only the Overworld is affected. You can change this in the config.

## Commands (`/fog`)
`status` · `setstage <0-3>` · `auto` · `reset` · `skipdays <n>` · `debug` · `selftest`
All commands except `status` need operator permission level 2. `selftest` builds test scenes in the sky above you and checks every protection rule.

## Configuration
- **Server** (`serverconfig/fogiscoming-server.toml`): stage days, density, damage and how fast it grows, grace time, light radius, shelter limits, affected dimensions.
- **Client** (`config/fogiscoming-client.toml`): HUD, sounds, clock volume, fog particles, built-in shaders and their quality (LOW/MEDIUM/HIGH), halos, film look, effect intensity.
- The tags `fogiscoming:fog_safe_lights`, `fog_light_blacklist` and `fog_permeable` can be extended with a datapack.

## Compatibility
- Minecraft **1.20.1**, Forge **47.x**.
- Works with **Oculus** shader packs: the mod's built-in shaders turn themselves off and the pack draws the image. The companion pack **Fog Is Coming Shaders** draws the mod's fog volumetrically.

---

### На русском

**Сутки мир спокоен, только тикают часы. Потом приходит туман.** С каждым днём он гуще и темнее, а на восьмой день начинает убивать. Спасают только **свет** (факелы, фонари, костры, светокамень…) и **закрытое укрытие**. Солнце не спасает, яма с блоком сверху тоже.

В моде есть встроенные шейдеры: объёмный туман, ореолы у света и киноэффект. Работает в одиночной игре и на сервере; мод нужен и на сервере, и у всех игроков. Есть команды `/fog` и подробные настройки.
